from flask import Flask, make_response, json, jsonify, redirect, url_for, request, render_template
import requests

app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template("public/index.html")

if __name__ == '__main__':
    app.run()
